﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;


namespace AppTyV
{
    public enum Puesto
    {
        Arquero,
        Defensor,
        Mediocampista,
        Delantero
    }
}
