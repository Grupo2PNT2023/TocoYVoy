﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;
using System.Linq;
using System.Threading.Tasks;


namespace AppTyV.Models
{
    public class Jugador
    {
        [Key]
        [DatabaseGenerated(DatabaseGeneratedOption.Identity)]
        public int Id { get; set; }
        public required string Nombre { get; set; }
        public required string Apellido { get; set; }
        public DateTime Nacimiento { get; set; }
        [EnumDataType(typeof(Puesto))]
        public Puesto Puesto { get; set; }
        [EnumDataType(typeof(PiernaHabil))]
        public PiernaHabil PiernaHabil { get; set; }
        [EnumDataType(typeof(Sexo))]
        public Sexo Sexo { get; set; }
    }
}
