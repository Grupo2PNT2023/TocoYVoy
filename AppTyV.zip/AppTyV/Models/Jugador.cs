﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;
using System.Linq;
using System.Threading.Tasks;


namespace AppTyV.Models
{
    public class Jugador
    {
        [Key]
        [DatabaseGenerated(DatabaseGeneratedOption.Identity)]
        public int id { get; set; }
        public String nombre { get; set; }
        public String apellido { get; set; }
        public DateTime nacimiento { get; set; }
        [EnumDataType(typeof(Puesto))]
        public Puesto puesto { get; set; }
        [EnumDataType(typeof(PiernaHabil))]
        public PiernaHabil piernaHabil { get; set; }
        [EnumDataType(typeof(Sexo))]
        public Sexo sexo { get; set; }
    }
}
