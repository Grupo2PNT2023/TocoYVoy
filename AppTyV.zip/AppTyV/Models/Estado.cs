﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace AppTyV
{
    public enum Estado
    {
        Activo,
        Cerrado,
        Suspendido
    }
}
