﻿using AppTyV.Models;
using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;
using System.Linq;
using System.Threading.Tasks;

namespace AppTyV

{
    public class Partido
    {
        [Key]
        [DatabaseGenerated(DatabaseGeneratedOption.Identity)]
        public int id { get; set; }
        public String lugar { get; set; }
        public DateTime fecha { get; set; }
        public DateTime hora { get; set; }
        public int totalJugadores { get; set; }
        public List<Jugador> jugadoresConfirmados = new List<Jugador>();
        [EnumDataType(typeof(Tipo))]
        public Tipo tipo { get; set; }
        [EnumDataType(typeof(Estado))]
        public Estado estado { get; set; }

        /* public Partido(string lugar, DateTime fecha, DateTime hora,
                         int totalJugadores, Tipo tipo)
        {
            _lugar = lugar;
            _fecha = fecha;
            _hora = hora;
            _totalJugadores = totalJugadores;
            _tipo = tipo;
            _estado = Estado.Activo;
        }

        public int MyProperty { get; set; }




             public Boolean agregarJugador (Jugador jug)
            {
                Boolean sePudo = false;
                _jugadoresConfirmados.Add(jug);

                return sePudo;
            }

            public Boolean cumpleRequisitos (Jugador jug)
            {
                return false;
            }

            public Boolean buscarJugador(Jugador jug)
            {
                Boolean esta = false;
                Jugador jugadorBuscado = null;
                int idx = 0;
                    while(jugadorBuscado == null && !esta) { 

                }
                return esta;
            }

            */
    }
}
