﻿using AppTyV.Models;
using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;
using System.Linq;
using System.Threading.Tasks;

namespace AppTyV

{
    public class Partido
    {
        [Key]
        [DatabaseGenerated(DatabaseGeneratedOption.Identity)]
        public int Id { get; set; }
        public required string Lugar { get; set; }
        public DateTime Fecha { get; set; }
        public DateTime Hora { get; set; }
        public int TotalJugadores { get; set; }
        public List<Jugador> JugadoresConfirmados = new();
        [EnumDataType(typeof(Tipo))]
        public Tipo Tipo { get; set; }
        [EnumDataType(typeof(Estado))]
        public Estado Estado { get; set; }

        /* public Partido(string lugar, DateTime fecha, DateTime hora,
                         int totalJugadores, Tipo tipo)
        {
            _lugar = lugar;
            _fecha = fecha;
            _hora = hora;
            _totalJugadores = totalJugadores;
            _tipo = tipo;
            _estado = Estado.Activo;
        }

        public int MyProperty { get; set; }




             public Boolean agregarJugador (Jugador jug)
            {
                Boolean sePudo = false;
                _jugadoresConfirmados.Add(jug);

                return sePudo;
            }

            public Boolean cumpleRequisitos (Jugador jug)
            {
                return false;
            }

            public Boolean buscarJugador(Jugador jug)
            {
                Boolean esta = false;
                Jugador jugadorBuscado = null;
                int idx = 0;
                    while(jugadorBuscado == null && !esta) { 

                }
                return esta;
            }

            */
    }
}
